// src/App.jsx
import React, { useState, useRef, useEffect } from "react";
import { ShoppingCart, MessageCircle, X, Trash2, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

const products = [
  {
    id: 1,
    name: "Accesorio 1",
    description: "Descripción del producto",
    price: 10,
    image: "/img/producto1.jpg",
  },
  {
    id: 2,
    name: "Accesorio 2",
    description: "Descripción del producto",
    price: 20,
    image: "https://img.freepik.com/vector-premium/lindo-capibara-dibujos-animados-sostiene-bebida-vaso-carton-pajita-sobre-fondo-blanco_555467-6717.jpg",
  }
];

export default function TechStorePage() {
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    const storedCart = localStorage.getItem("cart");
    if (storedCart) setCart(JSON.parse(storedCart));
  }, []);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product) => {
    setCart((prev) => [...prev, product]);
  };

  const removeFromCart = (productName) => {
    setCart((prev) => prev.filter(p => p.name !== productName));
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const confirmCheckout = () => {
    setCart([]);
    setCartOpen(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden font-sans">
      <div className="fixed top-0 left-0 w-full h-full -z-10 overflow-hidden">
        <video className="w-full h-full object-cover" autoPlay loop muted>
          <source src="/video/ensamblaje.mp4" type="video/mp4" />
        </video>
        <div className="absolute top-0 left-0 w-full h-full bg-black/60" />
      </div>

      <button onClick={() => setCartOpen(!cartOpen)} className="fixed top-4 right-4 z-50 bg-white/10 p-3 rounded-full border border-white">
        <ShoppingCart className="w-6 h-6 text-white" />
      </button>

      <button onClick={() => setChatOpen(!chatOpen)} className="fixed bottom-4 right-4 z-50 bg-white/10 p-3 rounded-full border border-white">
        <MessageCircle className="w-6 h-6 text-white" />
      </button>

      {chatOpen && (
        <div className="fixed bottom-20 right-4 bg-white text-black p-4 rounded shadow-lg w-72 z-50">
          <p className="font-bold mb-2">Asistente Virtual</p>
          <p>Hola 👋 ¿En qué puedo ayudarte?</p>
        </div>
      )}

      {showSuccess && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed top-6 left-1/2 transform -translate-x-1/2 bg-green-600 text-white px-6 py-3 rounded-full z-50 shadow-lg flex items-center gap-2"
        >
          <CheckCircle className="w-5 h-5" />
          <span>¡Gracias por tu compra!</span>
        </motion.div>
      )}

      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 mt-16">
        {products.map(product => (
          <div key={product.id} className="bg-white/10 border border-white p-4 rounded-lg shadow-md text-center">
            <img src={product.image} alt={product.name} className="mx-auto h-40 object-cover mb-4" />
            <h3 className="text-xl font-bold">{product.name}</h3>
            <p className="text-sm">{product.description}</p>
            <p className="text-lg mt-2">${product.price}</p>
            <button onClick={() => addToCart(product)} className="mt-2 bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded">Agregar al carrito</button>
          </div>
        ))}
      </div>

      {cartOpen && (
        <div className="fixed right-0 top-0 w-80 bg-black text-white p-6 shadow-lg h-full z-40 overflow-y-auto border-l border-white">
          <h2 className="text-xl font-bold mb-4">Carrito</h2>
          {cart.map((item, i) => (
            <div key={i} className="flex justify-between items-center border-b py-2">
              <span>{item.name}</span>
              <button onClick={() => removeFromCart(item.name)}><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
          <p className="mt-4">Total: ${total}</p>
          <button onClick={confirmCheckout} className="bg-green-600 hover:bg-green-800 text-white mt-4 px-4 py-2 rounded">Pagar</button>
        </div>
      )}
    </div>
  );
}
